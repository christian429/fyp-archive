# FYP Archive & Management System

Web-based archive for final year project reports — built with React (Vite) and Supabase.

## Setup

1. **Create your Supabase project** at supabase.com, then run `sql/01_profiles_schema.sql`
   in the Supabase SQL Editor.

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Configure environment variables:**
   ```
   cp .env.example .env
   ```
   Then fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` from
   Supabase Dashboard > Project Settings > API.

4. **Run the dev server:**
   ```
   npm run dev
   ```
   App runs at http://localhost:5173

## What's implemented so far

- **US-01 (Onboarding/Sign-up):** `/signup`, `/login`, `/dashboard` pages,
  wired to Supabase Auth. New users pick a role (student/lecturer/admin);
  a `profiles` row is auto-created via a Postgres trigger.

## Next up

- US-02: Project upload form (Supabase Storage)
- US-03: Duplication check on project titles
- US-04: Search/filter archive
- US-05 / US-06: Admin dashboard (approve staff roles, manage records)
